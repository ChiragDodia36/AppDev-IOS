// Project Name: StepCount
// Team Member 1: Chirag Dodia (cpdodia@iu.edu)
// Team Member 2: Shreyas Jadhav (shrejadh@iu.edu)
// Date: 05/06/2025

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

